package com.kevin.countryinfo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.util.Log
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun clickFlag(view: View) {
        val radioGroup : RadioGroup = findViewById(R.id.flags)
        val checkedButtonId: Int = radioGroup.checkedRadioButtonId
        val countryButton: RadioButton = findViewById(checkedButtonId)
        val country = countryButton.text.toString()
        Log.d("Country selected", country)

        val description = findViewById<TextView>(R.id.description)
        val image = findViewById<ImageView>(R.id.flagView)

        when (country) {
            "UK" -> {
                image.setImageResource(R.drawable.uk)
                description.text = getString(R.string.uk_description)
            }
            "IT" -> {
                image.setImageResource(R.drawable.it)
                description.text = getString(R.string.it_description)
            }
            "ES" -> {
                image.setImageResource(R.drawable.es)
                description.text = getString(R.string.es_description)
            }
            "FR" -> {
                image.setImageResource(R.drawable.fr)
                description.text = getString(R.string.fr_description)
            }
            else -> {
                Log.d("Country selected", "Invalid country")
            }
        }

    }
}