package com.kevin.camera

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CameraSettingsPart2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_camera_settings_part2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        findViewById<Button>(R.id.backToSettingsPart1Button).setOnClickListener(onClickBackToPart1(view = findViewById(R.id.backToSettingsPart1Button)))
        findViewById<Button>(R.id.goToSettingsPart3Button).setOnClickListener(onClickGoToPart3(view = findViewById(R.id.goToSettingsPart3Button)))

    }

    private fun onClickBackToPart1 (view: View) = View.OnClickListener{
        val i = Intent(this, CameraSettingsPart1::class.java)
        startActivity(i)
    }

    private fun onClickGoToPart3 (view: View) = View.OnClickListener{
        val i = Intent(this, CameraSettingsPart3::class.java)
        startActivity(i)
    }
}