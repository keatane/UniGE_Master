package com.kevin.camera

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CameraSettingsPart3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_camera_settings_part3)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        findViewById<Button>(R.id.backToSettingsPart2Button).setOnClickListener(onClickBackToPart2(view = findViewById(R.id.backToSettingsPart2Button)))
    }

    private fun onClickBackToPart2 (view: View) = View.OnClickListener{
        val i = Intent(this, CameraSettingsPart2::class.java)
        startActivity(i)
    }
}