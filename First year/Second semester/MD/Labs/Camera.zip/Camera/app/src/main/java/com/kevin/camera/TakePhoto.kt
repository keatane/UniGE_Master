package com.kevin.camera

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.drawToBitmap
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


class TakePhoto : AppCompatActivity() {
    private val REQUEST_IMAGE_CAPTURE = 1
    private var top_occupied: Boolean = false
    private var bottom_occupied: Boolean = false
    private var top_time: String = ""
    private var bottom_time: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_take_photo)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        findViewById<Button>(R.id.takePhotoButton).setOnClickListener(onClickTakePhoto(view = findViewById(R.id.takePhotoButton)))
        findViewById<ImageView>(R.id.topImage).setOnClickListener(onClickToastInfoTop(view = findViewById(R.id.topImage)))
        findViewById<ImageView>(R.id.bottomImage).setOnClickListener(onClickToastInfoBottom(view = findViewById(R.id.bottomImage)))
        findViewById<ImageView>(R.id.topImage).setOnLongClickListener(onLongClickDeleteTop(view = findViewById(R.id.topImage)))
        findViewById<ImageView>(R.id.bottomImage).setOnLongClickListener(onLongClickDeleteBottom(view = findViewById(R.id.bottomImage)))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Log.d(this::class.simpleName, "Updating photo...")
            val imageBitmap = data?.extras?.get("data") as Bitmap
            handleAddingImages(imageBitmap)
        }
    }

    private fun onClickTakePhoto(view: View) = View.OnClickListener {
        // Log with tag the name of the class
        Log.d(this::class.simpleName, "Taking photo...")
        val i = Intent("android.media.action.IMAGE_CAPTURE")
        val chooser = Intent.createChooser(i, null)
        startActivityForResult(i, REQUEST_IMAGE_CAPTURE)
    }

    private fun getCurrentDateTime(): String {
        val currentDateTime = LocalDateTime.now()
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        return currentDateTime.format(formatter)
    }

    private fun handleAddingImages(imageBitmap: Bitmap) {
        if (!top_occupied) {
            findViewById<ImageView>(R.id.topImage).setImageBitmap(imageBitmap)
            top_occupied = true
            // Get time of system with a format data with year, month and day
            top_time = getCurrentDateTime()

        }
        else if (!bottom_occupied) {
            findViewById<ImageView>(R.id.bottomImage).setImageBitmap(imageBitmap)
            bottom_occupied = true
            bottom_time = getCurrentDateTime()
        }
        else{
            findViewById<ImageView>(R.id.bottomImage).setImageBitmap(findViewById<ImageView>(R.id.topImage).drawToBitmap())
            findViewById<ImageView>(R.id.topImage).setImageBitmap(imageBitmap)
        }
    }

    private fun onClickToastInfoTop(view: View) = View.OnClickListener {
        if (top_occupied) {
            Log.d(this::class.simpleName, "Showing top image toast...")
            showToast(top_time)
        }
    }

    private fun onClickToastInfoBottom(view: View) = View.OnClickListener {
        if (bottom_occupied) {
            Log.d(this::class.simpleName, "Showing bottom image toast...")
            showToast(bottom_time)
        }
    }

    private fun onLongClickDeleteTop(view: View) = View.OnLongClickListener {
        Log.d(this::class.simpleName, "Deleting top image...")
        if (!bottom_occupied) {
            view as ImageView
            view.setImageBitmap(null)
            top_occupied = false
        }
        else {
            // Shift bottom image to top
            view as ImageView
            view.setImageBitmap(findViewById<ImageView>(R.id.bottomImage).getDrawable().toBitmap())
            findViewById<ImageView>(R.id.bottomImage).setImageBitmap(null)
            bottom_occupied = false
            top_time = bottom_time
        }
        showToast("Top image deleted")
        true
    }

    private fun onLongClickDeleteBottom(view: View) = View.OnLongClickListener {
        Log.d(this::class.simpleName, "Deleting bottom image...")
        view as ImageView
        view.setImageBitmap(null)
        bottom_occupied = false
        showToast("Bottom image deleted")
        true
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        Log.d(this::class.simpleName, "Toast shown at $message")
    }
}