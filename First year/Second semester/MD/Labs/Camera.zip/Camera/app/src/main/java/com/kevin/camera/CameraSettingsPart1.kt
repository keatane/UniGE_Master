package com.kevin.camera

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class CameraSettingsPart1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_camera_settings_part1)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        findViewById<Button>(R.id.goToSettingsPart2Button).setOnClickListener(onClickGoToPart2(view = findViewById(R.id.goToSettingsPart2Button)))
        findViewById<Button>(R.id.returnButton).setOnClickListener(onClickReturn(view = findViewById(R.id.returnButton)))
        findViewById<Button>(R.id.testListenerButton).setOnClickListener(onClickTestListener(view = findViewById(R.id.testListenerButton)))
        findViewById<Button>(R.id.testListenerButton).setOnLongClickListener(onLongClickTestListener(view = findViewById(R.id.testListenerButton)))

    }

    private fun onClickReturn (view: View) = View.OnClickListener{
        val i = Intent(this, MainActivity::class.java)
        startActivity(i)
    }

    private fun onClickGoToPart2 (view: View) = View.OnClickListener{
        val i = Intent(this, CameraSettingsPart2::class.java)
        startActivity(i)
    }

    private fun onClickTestListener (view: View) = View.OnClickListener{
        val textView = findViewById<TextView>(R.id.eventText)
        textView.text = getString(R.string.click_event)
    }

    private fun onLongClickTestListener (view: View) = View.OnLongClickListener{
        val textView = findViewById<TextView>(R.id.eventText)
        textView.text = getString(R.string.long_click_event)
        true
    }
}