package com.kevin.sensorapp

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class LightSensor : AppCompatActivity() {
    private lateinit var sensorManagerSystem: SensorManager
    private lateinit var sensorManagerHandler: SensorActivity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_light_sensor)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        sensorManagerSystem = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorManagerHandler = SensorActivity(sensorManagerSystem = sensorManagerSystem, lightValueTextView = findViewById(R.id.lightValue))
    }

    override fun onResume() {
        super.onResume()
        sensorManagerHandler.onResume()
    }

    override fun onPause() {
        super.onPause()
        sensorManagerHandler.onPause()
    }

    class SensorActivity(private val sensorManagerSystem: SensorManager, val lightValueTextView: TextView): SensorEventListener {
        private var mLight: Sensor? = null

        init {
            mLight = sensorManagerSystem.getDefaultSensor(Sensor.TYPE_LIGHT)
        }

        override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
            // Do something here if sensor accuracy changes.
        }

        override fun onSensorChanged(event: SensorEvent) {
            // The light sensor returns a single value.
            // Many sensors return 3 values, one for each axis.
            val lux = event.values[0]
            // Do something with this sensor value.
            lightValueTextView.text = lux.toString()
        }

        public fun onResume() {
            mLight?.also { light ->
                sensorManagerSystem.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL)
            }
        }

        public fun onPause() {
            sensorManagerSystem.unregisterListener(this)
        }
    }
}