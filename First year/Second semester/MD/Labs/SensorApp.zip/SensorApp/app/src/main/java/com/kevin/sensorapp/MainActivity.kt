package com.kevin.sensorapp

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.realTimeLightButton).setOnClickListener(onClickRealtimeLight(view = findViewById(R.id.realTimeLightButton)))
        findViewById<Button>(R.id.chartButton).setOnClickListener(onClickChart(view = findViewById(R.id.chartButton)))

        initializeNumberOfSensors()
        initializeListOfSensors()
    }

    private fun initializeNumberOfSensors() {
        val sensorManagerSystem = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensorList = sensorManagerSystem.getSensorList(Sensor.TYPE_ALL)
        findViewById<TextView>(R.id.numSensorsText).text = buildString {
            append("Number of sensors: ")
            append(sensorList.size.toString())
        }
    }

    private fun initializeListOfSensors() {
        val sensorManagerSystem = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensorList = sensorManagerSystem.getSensorList(Sensor.TYPE_ALL)
        if (sensorList.isEmpty()) {
            return
        }
        val sensorListText = findViewById<LinearLayout>(R.id.sensorListText)
        sensorList.forEach {
            val sensorText = TextView(this)
            sensorText.text = it.toString()
            sensorListText.addView(sensorText)
        }
    }

    private fun onClickRealtimeLight(view: Button): (v: android.view.View) -> Unit = {
        val i: Intent = Intent(this, LightSensor::class.java)
        startActivity(i)
    }

    private fun onClickChart(view: Button): (v: android.view.View) -> Unit = {
        val i: Intent = Intent(this, ChartActivity::class.java)
        startActivity(i)
    }

}