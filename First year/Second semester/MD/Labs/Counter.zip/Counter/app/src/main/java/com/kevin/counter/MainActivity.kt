package com.kevin.counter

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val out = MainActivity::class.java.simpleName
    private var counter: Float = 0.0F

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun reduceByStepView(@Suppress("UNUSED_PARAMETER") view: View) {
        val stepText = findViewById<EditText>(R.id.stepValue).text
        val step = stepText.toString().toFloatOrNull()
        if (step === null){
            Log.d(out, "step is null")
            // no counter value change
            return
        }
        reduceByStep(step)
    }

    private fun reduceByStep(step: Float){
        Log.d(out, "reducing")
        counter -= step
        setCounter()
    }

    fun increaseByStepView(@Suppress("UNUSED_PARAMETER") view: View) {
        val stepText = findViewById<EditText>(R.id.stepValue).text
        val step = stepText.toString().toFloatOrNull()
        if (step === null){
            Log.d(out, "step is null")
            // no counter value change
            return
        }
        increaseByStep(step)
    }

    private fun increaseByStep(step: Float){
        Log.d(out, "increasing")
        counter += step
        setCounter()
    }

    private fun setCounter(){
        val counterText = findViewById<TextView>(R.id.counterValue)
        val counter = "%.2f".format(counter)
        "Value Counter: $counter".also { counterText.text = it }
    }
}