package com.kevin.callsmsmanager

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class IntCall : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_int_call)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val intent = intent
        val prefix = intent.getStringExtra("prefix")
        val prefixText = findViewById<TextView>(R.id.prefixText)
        // select a substring of the first 3 characters of the prefix (without country)
        prefixText.text = prefix?.substring(0, 3)

        findViewById<Button>(R.id.intComposeButton).setOnClickListener(onClickCompose(view = findViewById(R.id.intComposeButton)))
        findViewById<Button>(R.id.intCallButton).setOnClickListener(onClickCall(view = findViewById(R.id.intCallButton)))
    }

    private fun onClickCompose (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        if (findViewById<EditText>(R.id.inputIntCallNumber).getText().toString() == "") return@OnClickListener
        startIntCompose()
    }

    private fun onClickCall (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        if (findViewById<EditText>(R.id.inputIntCallNumber).getText().toString() == "") return@OnClickListener
        startIntCall()
    }

    private fun startIntCompose(){
        val intentImplicit = Intent(Intent.ACTION_DIAL)
        val uri = "tel:" + findViewById<TextView>(R.id.prefixText).getText().toString() + findViewById<EditText>(R.id.inputIntCallNumber).getText().toString()
        intentImplicit.setData(Uri.parse(uri))
        startActivity(intentImplicit)
    }

    private fun startIntCall(){
        val intentImplicit = Intent(Intent.ACTION_CALL)
        val uri = "tel:" + findViewById<TextView>(R.id.prefixText).getText().toString() + findViewById<EditText>(R.id.inputIntCallNumber).getText().toString()
        intentImplicit.setData(Uri.parse(uri))
        try {
            startActivity(intentImplicit)
        } catch (e: SecurityException) {
            ActivityCompat.requestPermissions(
                this@IntCall, arrayOf(Manifest.permission.CALL_PHONE),
                1
            )
        }
    }
}