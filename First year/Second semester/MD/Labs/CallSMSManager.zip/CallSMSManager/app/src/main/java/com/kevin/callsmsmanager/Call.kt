package com.kevin.callsmsmanager

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class Call : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_call)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.composeButton).setOnClickListener(onClickCompose(view = findViewById(R.id.composeButton)))
        findViewById<Button>(R.id.callButton).setOnClickListener(onClickCall(view = findViewById(R.id.callButton)))
    }

    private fun onClickCompose (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        if (findViewById<EditText>(R.id.inputCallNumber).getText().toString() == "") return@OnClickListener
        startCompose()
    }

    private fun onClickCall (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        if (findViewById<EditText>(R.id.inputCallNumber).getText().toString() == "") return@OnClickListener
        startCall()
    }

    private fun startCompose(){
        val intentImplicit = Intent(Intent.ACTION_DIAL)
        val uri = "tel:" + findViewById<EditText>(R.id.inputCallNumber).getText().toString()
        intentImplicit.setData(Uri.parse(uri))
        startActivity(intentImplicit)
    }

    private fun startCall(){
        val intentImplicit = Intent(Intent.ACTION_CALL)
        val uri = "tel:" + findViewById<EditText>(R.id.inputCallNumber).getText().toString()
        intentImplicit.setData(Uri.parse(uri))
        try {
            startActivity(intentImplicit)
        } catch (e: SecurityException) {
            ActivityCompat.requestPermissions(
                this@Call, arrayOf(Manifest.permission.CALL_PHONE),
                1
            )
        }
    }
}