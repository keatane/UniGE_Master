package com.kevin.callsmsmanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SMS : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_sms)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.sendButton).setOnClickListener(onClickSend(view = findViewById(R.id.sendButton)))
    }

    private fun onClickSend (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        if (findViewById<EditText>(R.id.inputSmsNumber).getText().toString() == "") return@OnClickListener
        sendSMS()
    }

    private fun sendSMS(){
        // Retrieve sms body
        val smsBody = findViewById<EditText>(R.id.smsText).getText().toString()
        if (smsBody == "") return

        // Create implicit intent
        val intentImplicit = Intent(Intent.ACTION_SENDTO)
        val uri = "smsto:" + findViewById<EditText>(R.id.inputSmsNumber).getText().toString()
        intentImplicit.setData(Uri.parse(uri))
        intentImplicit.putExtra("sms_body", smsBody)
        startActivity(intentImplicit)
    }
}