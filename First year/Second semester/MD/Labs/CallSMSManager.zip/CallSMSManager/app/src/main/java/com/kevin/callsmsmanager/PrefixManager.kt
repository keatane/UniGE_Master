package com.kevin.callsmsmanager

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class PrefixManager : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_prefix_manager)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.selectButton).setOnClickListener(onClickSelect(view = findViewById(R.id.selectButton)))
    }


    private fun onClickSelect (view: View) = View.OnClickListener{
        selectPrefix(view)
    }

    private fun selectPrefix(@Suppress("UNUSED_PARAMETER") view: View) {
        val implicitIntent = Intent(this, IntCall::class.java)

        // Get the selected radio button
        val radioGroup = findViewById<RadioGroup>(R.id.prefixGroup)
        val selectedId = radioGroup.checkedRadioButtonId
        val radioButton = findViewById<RadioButton>(selectedId)
        val prefix = radioButton.getText().toString()

        // Construct implicit intent
        implicitIntent.putExtra("prefix", prefix)
        startActivity(implicitIntent)
    }
}