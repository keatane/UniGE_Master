package com.kevin.calculator

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private var left : String = ""
    private var right : String = ""
    private var operator : String = ""
    private var completed : Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.one).setOnClickListener(onClickNumber(view = findViewById(R.id.one)))
        findViewById<Button>(R.id.two).setOnClickListener(onClickNumber(view = findViewById(R.id.two)))
        findViewById<Button>(R.id.three).setOnClickListener(onClickNumber(view = findViewById(R.id.three)))
        findViewById<Button>(R.id.four).setOnClickListener(onClickNumber(view = findViewById(R.id.four)))
        findViewById<Button>(R.id.five).setOnClickListener(onClickNumber(view = findViewById(R.id.five)))
        findViewById<Button>(R.id.six).setOnClickListener(onClickNumber(view = findViewById(R.id.six)))
        findViewById<Button>(R.id.seven).setOnClickListener(onClickNumber(view = findViewById(R.id.seven)))
        findViewById<Button>(R.id.eight).setOnClickListener(onClickNumber(view = findViewById(R.id.eight)))
        findViewById<Button>(R.id.nine).setOnClickListener(onClickNumber(view = findViewById(R.id.nine)))
        findViewById<Button>(R.id.zero).setOnClickListener(onClickNumber(view = findViewById(R.id.zero)))

        findViewById<Button>(R.id.plus).setOnClickListener(onClickOperator(view = findViewById(R.id.plus)))
        findViewById<Button>(R.id.minus).setOnClickListener(onClickOperator(view = findViewById(R.id.minus)))
        findViewById<Button>(R.id.multiply).setOnClickListener(onClickOperator(view = findViewById(R.id.multiply)))
        findViewById<Button>(R.id.divide).setOnClickListener(onClickOperator(view = findViewById(R.id.divide)))
        findViewById<Button>(R.id.dec).setOnClickListener(onClickDecimal(view = findViewById(R.id.dec)))

        findViewById<Button>(R.id.equal).setOnClickListener(onClickEqual())
        findViewById<Button>(R.id.clear).setOnClickListener(onClickClear())

        if (savedInstanceState != null) {
            left = savedInstanceState.getString("left").toString()
            right = savedInstanceState.getString("right").toString()
            operator = savedInstanceState.getString("operator").toString()
            completed = savedInstanceState.getBoolean("completed")
            updateResult(savedInstanceState.getString("result").toString())
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("result", findViewById<TextView>(R.id.result).getText().toString())
        outState.putString("left", left)
        outState.putString("right", right)
        outState.putString("operator", operator)
        outState.putBoolean("completed", completed)
    }

    private fun updateResult (result: String) {
        if (result.toFloat() == result.toFloat().toInt().toFloat())
            findViewById<TextView>(R.id.result).text = result.toFloat().toInt().toString()
        else
            findViewById<TextView>(R.id.result).text = result.toFloat().toString()
    }

    @SuppressLint("CutPasteId")
    private fun onClickNumber (view: View) = View.OnClickListener {
        val button = view as Button
        val number = button.text.toString()
        var current = findViewById<TextView>(R.id.result).text.toString()
        if (current.length == 14) return@OnClickListener
        if (current == "0" || current == "Error" || completed) {
            completed = false
            updateResult(number)
        }
        else{
            current += number
            findViewById<TextView>(R.id.result).text = current
        }
    }

    private fun onClickOperator (view: View) = View.OnClickListener{
        val button = view as Button
        operator = button.text.toString()
        left = findViewById<TextView>(R.id.result).text.toString()
        if (left == "Error") left = "0"
        updateResult("0")
    }

    private fun onClickEqual () = View.OnClickListener{
        if (operator == "") return@OnClickListener
        right = findViewById<TextView>(R.id.result).text.toString()
        when (operator) {
            "+" -> sum()
            "-" -> sub()
            "*" -> mul()
            "/" -> div()
        }
        completed = true
        right = ""
        operator = ""
    }

    private fun onClickClear () = View.OnClickListener{
        left = ""
        right = ""
        operator = ""
        completed = false
        updateResult("0")
    }

    @SuppressLint("CutPasteId")
    private fun onClickDecimal(view: View) = View.OnClickListener {
        var current = findViewById<TextView>(R.id.result).text.toString()
        if (current.contains(".")) return@OnClickListener
        current += "."
        findViewById<TextView>(R.id.result).text = current
    }

    private fun sum () {
        val result = left.toFloat() + right.toFloat()
        updateResult(result.toString())
    }

    private fun sub (){
        val result = left.toFloat() - right.toFloat()
        updateResult(result.toString())
    }

    private fun mul (){
        val result = left.toFloat() * right.toFloat()
        updateResult(result.toString())
    }

    @SuppressLint("SetTextI18n")
    private fun div (){
        if (right == "" || right == "0") {
            findViewById<TextView>(R.id.result).text = "Error"
            left = ""
            right = ""
            operator = ""
            completed = false
        }
        else{
            val result = left.toFloat() / right.toFloat()
            updateResult(result.toString())
        }
    }


}