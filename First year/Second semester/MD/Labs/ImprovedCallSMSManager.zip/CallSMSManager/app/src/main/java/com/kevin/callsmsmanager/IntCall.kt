package com.kevin.callsmsmanager

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.lang.String
import kotlin.Int
import kotlin.Suppress
import kotlin.arrayOf


@Suppress("DEPRECATION")
class IntCall : AppCompatActivity() {

    private val LOG_TAG = IntCall::class.simpleName
    val CHOOSE_PREFIX = 1
    val CHOOSE_SPECIAL_NUMBER = 2


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_int_call)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.intComposeButton).setOnClickListener(onClickCompose(view = findViewById(R.id.intComposeButton)))
        findViewById<Button>(R.id.intCallButton).setOnClickListener(onClickCall(view = findViewById(R.id.intCallButton)))
        findViewById<Button>(R.id.choosePrefix).setOnClickListener(onClickChoosePrefix(view = findViewById(R.id.choosePrefix)))
        findViewById<Button>(R.id.chooseSpecial).setOnClickListener(onClickSpecialNumber(view = findViewById(R.id.chooseSpecial)))

        if (savedInstanceState != null) {
            findViewById<EditText>(R.id.inputIntCallNumber).setText(savedInstanceState.getString("tel"))
            findViewById<TextView>(R.id.prefixText).text = savedInstanceState.getString("prefix").toString()
        }

    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tel", String.valueOf(findViewById<EditText>(R.id.inputIntCallNumber).getText().toString()))
        outState.putString("prefix", findViewById<TextView>(R.id.prefixText).getText().toString())
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CHOOSE_PREFIX) {
            if (resultCode == RESULT_OK) {
                val reply = data?.getStringExtra(PrefixManager.EXTRA_REPLY)
                if (reply != null) {
                    findViewById<TextView>(R.id.prefixText).text = reply.toString().substring(0, 3)
                }
            }
        }
        else if (requestCode == CHOOSE_SPECIAL_NUMBER) {
            if (resultCode == RESULT_OK) {
                val reply = data?.getStringExtra(SpecialNumber.EXTRA_REPLY)
                if (reply != null)
                    findViewById<EditText>(R.id.inputIntCallNumber).setText(reply.toString().substring(0, 5))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Log.d(LOG_TAG, "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d(LOG_TAG, "onPause")
    }


    private fun onClickCompose (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        if (findViewById<EditText>(R.id.inputIntCallNumber).getText().toString() == "") return@OnClickListener
        startIntCompose()
    }

    private fun onClickCall (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        if (findViewById<EditText>(R.id.inputIntCallNumber).getText().toString() == "") return@OnClickListener
        startIntCall()
    }

    private fun onClickChoosePrefix (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        val intent = Intent(this, PrefixManager::class.java)
        startActivityForResult(intent, CHOOSE_PREFIX)
    }

    private fun onClickSpecialNumber (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        val intent = Intent(this, SpecialNumber::class.java)
        startActivityForResult(intent, CHOOSE_SPECIAL_NUMBER)
    }

    private fun startIntCompose(){
        val intentImplicit = Intent(Intent.ACTION_DIAL)
        val uri = "tel:" + findViewById<TextView>(R.id.prefixText).getText().toString() + findViewById<EditText>(R.id.inputIntCallNumber).getText().toString()
        intentImplicit.setData(Uri.parse(uri))
        startActivity(intentImplicit)
    }

    private fun startIntCall(){
        val intentImplicit = Intent(Intent.ACTION_CALL)
        val uri = "tel:" + findViewById<TextView>(R.id.prefixText).getText().toString() + findViewById<EditText>(R.id.inputIntCallNumber).getText().toString()
        intentImplicit.setData(Uri.parse(uri))
        try {
            startActivity(intentImplicit)
        } catch (e: SecurityException) {
            ActivityCompat.requestPermissions(
                this@IntCall, arrayOf(Manifest.permission.CALL_PHONE),
                1
            )
        }
    }
}