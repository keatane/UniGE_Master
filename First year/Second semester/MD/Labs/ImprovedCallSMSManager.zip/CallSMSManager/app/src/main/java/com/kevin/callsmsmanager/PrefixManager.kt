package com.kevin.callsmsmanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class PrefixManager : AppCompatActivity() {

    private val LOG_TAG = PrefixManager::class.simpleName
    companion object {
        const val EXTRA_REPLY = "com.kevin.prefix-manager.REPLY"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_prefix_manager)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.selectPrefix).setOnClickListener(onClickSelectPrefix(view = findViewById(R.id.selectPrefix)))
        findViewById<Button>(R.id.findInfo).setOnClickListener(onClickFindInfo(view = findViewById(R.id.findInfo)))
    }

    override fun onResume() {
        super.onResume()
        Log.d(LOG_TAG, "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d(LOG_TAG, "onPause")
    }

    private fun onClickSelectPrefix (view: View) = View.OnClickListener{
        selectPrefix(view)
    }

    private fun onClickFindInfo (view: View) = View.OnClickListener{
        findInfo(view)
    }

    private fun selectPrefix(@Suppress("UNUSED_PARAMETER") view: View) {
        val replyIntent = Intent()

        // Get the selected radio button
        val radioGroup = findViewById<RadioGroup>(R.id.prefixGroup)
        val selectedId = radioGroup.checkedRadioButtonId
        val radioButton = findViewById<RadioButton>(selectedId)
        val prefix = radioButton.getText().toString()

        replyIntent.putExtra(EXTRA_REPLY, prefix)
        setResult(RESULT_OK, replyIntent)
        finish()
    }

    private fun findInfo(@Suppress("UNUSED_PARAMETER") view: View) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.setData(Uri.parse("https://en.wikipedia.org/wiki/List_of_international_call_prefixes"));
        startActivity(intent)
    }
}