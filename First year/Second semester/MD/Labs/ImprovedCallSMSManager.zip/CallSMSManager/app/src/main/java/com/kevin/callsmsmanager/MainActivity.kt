package com.kevin.callsmsmanager

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class MainActivity : AppCompatActivity() {

    private val LOG_TAG = MainActivity::class.simpleName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.callManagerButton).setOnClickListener(onClickCall(view = findViewById(R.id.callManagerButton)))
        findViewById<Button>(R.id.smsManagerButton).setOnClickListener(onClickSMS(view = findViewById(R.id.smsManagerButton)))
        findViewById<Button>(R.id.intCallManagerButton).setOnClickListener(onClickIntCall(view = findViewById(R.id.intCallManagerButton)))
    }

    override fun onResume() {
        super.onResume()
        Log.d(LOG_TAG, "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d(LOG_TAG, "onPause")
    }

    private fun onClickCall (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        startCall()
    }

    private fun onClickSMS (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        startSMS()
    }

    private fun onClickIntCall (@Suppress("UNUSED_PARAMETER") view: View) = View.OnClickListener{
        startIntCall()
    }

    private fun startCall(){
        val i = Intent(this, Call::class.java)
        startActivity(i)
    }

    private fun startSMS(){
        val i = Intent(this, SMS::class.java)
        startActivity(i)
    }

    private fun startIntCall(){
        val i = Intent(this, IntCall::class.java)
        startActivity(i)
    }
}