package com.kevin.callsmsmanager

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SpecialNumber : AppCompatActivity() {

    companion object {
        const val EXTRA_REPLY = "com.kevin.special-number.REPLY"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_special_number)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.selectSpecial).setOnClickListener(onClickSelectSpecial(view = findViewById(R.id.selectSpecial)))
    }

    private fun onClickSelectSpecial (view: View) = View.OnClickListener{
        selectSpecialNumber(view)
    }

    private fun selectSpecialNumber(@Suppress("UNUSED_PARAMETER") view: View) {
        val replyIntent = Intent()

        // Get the selected radio button
        val radioGroup = findViewById<RadioGroup>(R.id.prefixGroup)
        val selectedId = radioGroup.checkedRadioButtonId
        val radioButton = findViewById<RadioButton>(selectedId)
        val specialNumber = radioButton.getText().toString()

        replyIntent.putExtra(EXTRA_REPLY, specialNumber)
        setResult(RESULT_OK, replyIntent)
        finish()
    }
}